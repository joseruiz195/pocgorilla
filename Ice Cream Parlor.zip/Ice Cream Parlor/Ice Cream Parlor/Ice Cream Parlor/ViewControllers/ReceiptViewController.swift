//
//  ReceiptViewController.swift
//  Ice Cream Parlor
//
//  Created by Jose Pablo Ruiz Jimenez on 3/2/19.
//  Copyright © 2019 Jose Pablo Ruiz Jimenez. All rights reserved.
//

import UIKit

protocol ReceiptDelegate{
    func startNewOrder()
}

class ReceiptViewController: BaseViewController  {
    var products = [Products]()
    var delegate: ReceiptDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    @IBAction func startNewOrderButtonPressed(_ sender: Any) {
        delegate?.startNewOrder()
        dismiss(animated: true, completion: nil)
    }
}

extension ReceiptViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return products.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        let product = products[indexPath.row]
        cell.textLabel?.text = ""
        return cell
    }
}


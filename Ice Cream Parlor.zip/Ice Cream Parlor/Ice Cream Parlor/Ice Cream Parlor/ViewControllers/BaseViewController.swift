//
//  BaseViewController.swift
//  Ice Cream Parlor
//
//  Created by Jose Pablo Ruiz Jimenez on 3/2/19.
//  Copyright © 2019 Jose Pablo Ruiz Jimenez. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.defaultBackgroundColor()
    }
}

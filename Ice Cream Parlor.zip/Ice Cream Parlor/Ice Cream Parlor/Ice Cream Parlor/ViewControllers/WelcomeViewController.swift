//
//  WelcomeViewController.swift
//  Ice Cream Parlor
//
//  Created by Jose Pablo Ruiz Jimenez on 3/2/19.
//  Copyright © 2019 Jose Pablo Ruiz Jimenez. All rights reserved.
//

import UIKit

class WelcomeViewController: BaseViewController, ReceiptDelegate {
    var products = [Products]()
    @IBOutlet weak var gridView: UICollectionView!
    var count = [Int]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dataRequest(with: "https://gl-endpoint.herokuapp.com/products") { (error, results) in
            if error != nil {
                
            }
            else if let results = results {
                self.products = results
                self.count = Array(repeating: 0, count: self.products.count)
                DispatchQueue.main.async(execute: {
                    self.gridView.reloadData()
                })
            }
        }
    }
    @IBAction func orderButtonPressed(_ sender: Any) {
        var toOrder = [Products]()
        for i in count {
            if i > 0 {
                var product = products[i]
                product.count = count[i]
                toOrder.append(product)
            }
        }
        
        let receiptVC = storyboard?.instantiateViewController(withIdentifier: "ReceiptViewController") as? ReceiptViewController
        receiptVC?.delegate = self
        receiptVC?.products = toOrder
        present(receiptVC!, animated: true, completion: nil)
    }
    
    func startNewOrder() {
        self.count = Array(repeating: 0, count: self.products.count)
        DispatchQueue.main.async(execute: {
            self.gridView.reloadData()
        })
    }
    
    //APPError enum which shows all possible errors
    enum AppError: Error {
        case networkError(Error)
        case dataNotFound
        case jsonParsingError(Error)
        case invalidStatusCode(Int)
    }
    
    //Result enum to show success or failure
    enum Result<T> {
        case success(T)
        case failure(AppError)
    }
    
    //dataRequest which sends request to given URL
    func dataRequest(with url: String, completion: @escaping (Error?, [Products]?) -> Void) {
        
        //create the url with NSURL
        let dataURL = URL(string: url)! //change the url
        
        //create the session object
        let session = URLSession.shared
        
        //now create the URLRequest object using the url object
        let request = URLRequest(url: dataURL, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 60)
        
        //create dataTask using the session object to send data to the server
        let task = session.dataTask(with: request, completionHandler: { data, response, error in
            
            guard error == nil else {
                completion(AppError.networkError(error!), nil)
                return
            }
            
            guard let data = data else {
                completion(AppError.dataNotFound, nil)
                return
            }
            
            do {
                //create decodable object from data
                let JSON = try JSONSerialization.jsonObject(with: data, options: []) as? [[String: Any]] ?? [[String: Any]]()
                var results = [Products]()
                for raw in JSON {
                    let product = Products.init(dictionary: raw)
                    results.append(product)
                }
                completion(nil, results)
            } catch let error {
                completion(AppError.jsonParsingError(error as! DecodingError), nil)
            }
        })
        
        task.resume()
    }
}

extension WelcomeViewController:UICollectionViewDelegate, UICollectionViewDataSource {
    internal func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return ProductCell.requiredSize(collectionView)
    }
    
    internal func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return products.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProductCell", for: indexPath) as! ProductCell
        if indexPath.row < products.count {
            let product = products[indexPath.row]
            cell.setup(with: product, count: count[indexPath.row])
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        var current = count[indexPath.row]
        current += 1
        if current == 3 {
            count = Array(repeating: 0, count: products.count)
            collectionView.reloadData()
        }
        else {
            count[indexPath.row] = current
            collectionView.reloadItems(at: [indexPath])
        }
    }
}

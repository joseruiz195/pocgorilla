//
//  UIColor+IceCream.swift
//  Ice Cream Parlor
//
//  Created by Jose Pablo Ruiz Jimenez on 3/2/19.
//  Copyright © 2019 Jose Pablo Ruiz Jimenez. All rights reserved.
//

import UIKit

extension UIColor {
    convenience init?(fromHexString hexString: String?) {
        var cleanString = hexString?.replacingOccurrences(of: "#", with: "")
        if (cleanString?.count ?? 0) == 3 {
            cleanString = "\((cleanString as NSString?)?.substring(with: NSRange(location: 0, length: 1)) ?? "")\((cleanString as NSString?)?.substring(with: NSRange(location: 0, length: 1)) ?? "")\((cleanString as NSString?)?.substring(with: NSRange(location: 1, length: 1)) ?? "")\((cleanString as NSString?)?.substring(with: NSRange(location: 1, length: 1)) ?? "")\((cleanString as NSString?)?.substring(with: NSRange(location: 2, length: 1)) ?? "")\((cleanString as NSString?)?.substring(with: NSRange(location: 2, length: 1)) ?? "")"
        }
        if (cleanString?.count ?? 0) == 6 {
            cleanString = "\(cleanString ?? "")ff"
        }
        var baseValue: UInt32 = 0
        guard Scanner(string: cleanString ?? "").scanHexInt32(&baseValue) else {
            return nil
        }
        
        let red: Float = Float(((baseValue >> 24) & 0xff)) / 255.0
        let green: Float = Float(((baseValue >> 16) & 0xff)) / 255.0
        let blue: Float = Float(((baseValue >> 8) & 0xff)) / 255.0
        let alpha: Float = Float(((baseValue >> 0) & 0xff)) / 255.0
        self.init(red: CGFloat(red), green: CGFloat(green), blue: CGFloat(blue), alpha: CGFloat(alpha))
    }
    
    class func defaultBackgroundColor() -> UIColor? {
        return UIColor(red: 127.0/255.0, green: 208.0/255.0, blue: 211.0/255.0, alpha: 1.0)
    }
}

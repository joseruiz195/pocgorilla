//
//  ProductCell.swift
//  Ice Cream Parlor
//
//  Created by Jose Pablo Ruiz Jimenez on 3/2/19.
//  Copyright © 2019 Jose Pablo Ruiz Jimenez. All rights reserved.
//

import UIKit

class ProductCell: UICollectionViewCell {
    
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var priceLabel: UILabel!
    @IBOutlet private weak var image: UIImageView!
    @IBOutlet private weak var circle: UIView!
    @IBOutlet private weak var number: UILabel!
    
    public func setup(with product: Products, count: Int) {
        titleLabel.text = "\(product.name1) \(product.name2)"
        priceLabel.text = product.price
        image.image = UIImage(named: product.type)
        circle.backgroundColor = UIColor.init(fromHexString: product.bg_color)
        number.text = (count > 0) ? "\(count)" : ""
        number.textColor = UIColor.defaultBackgroundColor()
    }
    
    class func requiredSize(_ collectionView: UICollectionView) -> CGSize {
        let flow = collectionView.collectionViewLayout as? UICollectionViewFlowLayout
        
        let leftInset: CGFloat? = flow?.sectionInset.left
        let rightInset: CGFloat? = flow?.sectionInset.right
        let totalWidth = collectionView.frame.width
        
        let numberOfColumns = 2
        let cellWidth = totalWidth / CGFloat(numberOfColumns)
        let finalWidth: CGFloat = cellWidth - (leftInset ?? 0.0) - (rightInset ?? 0.0)
        let height: CGFloat = 150
        
        return CGSize(width: finalWidth, height: height)
    }
}

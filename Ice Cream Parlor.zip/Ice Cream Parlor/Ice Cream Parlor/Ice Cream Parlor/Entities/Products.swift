//
//  Products.swift
//  Ice Cream Parlor
//
//  Created by Jose Pablo Ruiz Jimenez on 3/2/19.
//  Copyright © 2019 Jose Pablo Ruiz Jimenez. All rights reserved.
//

import Foundation

struct Products: Decodable {
    let name1: String
    let name2: String
    let price: String
    let bg_color: String
    let type: String
    var count = 0
    
    init(dictionary: [String: Any]) {
        self.name1 = dictionary["name1"] as? String ?? ""
        self.name2 = dictionary["name2"] as? String ?? ""
        self.price = dictionary["price"] as? String ?? ""
        self.bg_color = dictionary["bg_color"] as? String ?? ""
        self.type = dictionary["type"] as? String ?? ""
    }
}
